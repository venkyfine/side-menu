//
//  RoundView.swift
//  SIdeMenuScreen

import UIKit

// Use Fot the RoundView
class RoundView : UIView{
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initialize()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        DispatchQueue.main.async {
            self.initialize()
        }
    }
    
    private func initialize() {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.layer.masksToBounds = true
        self.clipsToBounds = true
    }
}
