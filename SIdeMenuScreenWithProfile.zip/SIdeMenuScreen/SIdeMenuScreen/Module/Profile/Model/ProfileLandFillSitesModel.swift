//
//  ProfileLandFillSitesModel.swift
//  SIdeMenuScreen

import UIKit

struct ProfileLandFillSitesModel {
    let name: String
    let role: String
}
