//
//  ProfileSectionHeaderView.swift
//  SIdeMenuScreen

import UIKit

class ProfileSectionHeaderView: UITableViewHeaderFooterView, NibLoadableView, ReusableView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
