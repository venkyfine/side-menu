//
//  ProfileLandFillSitesTableViewCell.swift
//  SIdeMenuScreen

import UIKit

class ProfileLandFillSitesTableViewCell: UITableViewCell, NibLoadableView, ReusableView {

    @IBOutlet weak var viewContent: UIView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblRole: UILabel!
    
    var landFillSiteObj: ProfileLandFillSitesModel! {
        didSet {
            setData()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configureCell()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    private func configureCell() {
        self.viewContent.layer.cornerRadius = 19
        self.viewContent.layer.borderWidth = 1
        self.viewContent.layer.borderColor = #colorLiteral(red: 0.7764705882, green: 0.7764705882, blue: 0.737254902, alpha: 1).cgColor
    }
    
    private func setData() {
        self.lblName.text = landFillSiteObj.name
        self.lblRole.text = landFillSiteObj.role
    }
    
}
