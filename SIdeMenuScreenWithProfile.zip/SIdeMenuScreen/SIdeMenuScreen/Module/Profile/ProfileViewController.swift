//
//  ProfileViewController.swift
//  SIdeMenuScreen

import UIKit

enum ProfileSection: String, CaseIterable {
    case profile = "Profile"
    case landfillSites = "Landfill Sites"
}

class ProfileViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    
    var landfillSites: [ProfileLandFillSitesModel] = [] {
        didSet {
            tblView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(ProfileInfoTableViewCell.self)
        tblView.register(ProfileLandFillSitesTableViewCell.self)
        tblView.registerHeaderFooter(ProfileSectionHeaderView.self)
        prepareData()
        // Do any additional setup after loading the view.
    }
    
    private func prepareData() {
        landfillSites.append(contentsOf:
                                [ProfileLandFillSitesModel(name: "Anderson (S05429)", role: "Role - Technician"),
                                 ProfileLandFillSitesModel(name: "Altamont (S04305)", role: "Role - Manager"),
                                 ProfileLandFillSitesModel(name: "Amelia (S02898)", role: "Role - Admin")
                                ])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ProfileViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return ProfileSection.allCases.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let section = ProfileSection.allCases[section]
        switch section {
            case .profile:
                return 1
            case .landfillSites:
                return landfillSites.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = ProfileSection.allCases[indexPath.section]
        switch section {
            case .profile:
                let cell: ProfileInfoTableViewCell = tableView.cellForItemAtIndexPath(indexPath: indexPath)
                return cell
            case .landfillSites:
                let cell: ProfileLandFillSitesTableViewCell = tableView.cellForItemAtIndexPath(indexPath: indexPath)
                cell.landFillSiteObj = landfillSites[indexPath.row]
                return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        let section = ProfileSection.allCases[section]
        switch section {
            case .profile:
                return 0
            case .landfillSites:
                return UITableView.automaticDimension
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let section = ProfileSection.allCases[section]
        switch section {
            case .profile:
                return UIView()
            case .landfillSites:
                let view  = tblView.dequeueReusableHeaderFooterView(withIdentifier: ProfileSectionHeaderView.reuseIdentifier) as! ProfileSectionHeaderView
                return view
        }
    }
}
