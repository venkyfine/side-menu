//
//  NotificationSectionHeaderView.swift
//  SIdeMenuScreen

import UIKit

class NotificationSectionHeaderView: UITableViewHeaderFooterView, NibLoadableView, ReusableView {

    @IBOutlet weak var viewSeperator: UIView!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
